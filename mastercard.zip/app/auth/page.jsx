"use client";
import LogoSVG from "@/components/common/logoSVG";
import React, { useState } from "react";
import LoginForm from "./loginForm";
import SignUpForm from "./signUpForm";

function Auth() {
  const modes = { login: "login", signUp: "signUp" };
  const [mode, setMode] = useState(modes.login);
  const toggleMode = () => {
    setMode((current) =>
      current === modes.login ? modes.signUp : modes.login
    );
  };
  return (
    <div className="h-[96vh] flex flex-col">
      {/* header banner */}
      <div className="bg-gradient-to-l from-[#201348] to-[#0D0D1B] px-5 py-6">
        <div className="mt-4">
          <LogoSVG />
        </div>
        <h3
          className="text-grad mt-4 text-2xl font-bold bg-gradient-to-r from-white to-[#ffffff98] inline-block text-transparent bg-clip-text"
        >
          {/* adding gradiant to text */}
          Get started now
        </h3>
        <h6 className="mt-2 text-sm font-light text-white">
          Create an account or log in to app.
        </h6>
      </div>
      {/* body */}
      <div className="px-5 py-6 flex-grow relative">
        {/* Login/sign up sitcher */}
        <div className="relative grid grid-cols-2 text-center bg-[#EFEFEF] rounded-xl p-2 text-sm font-medium">
          <button
            onClick={toggleMode}
            className="rounded-lg py-3 transition-colors z-10"
          >
            Log in
          </button>
          <button
            onClick={toggleMode}
            className="rounded-lg py-3 transition-colors z-10"
          >
            Sing up
          </button>
          <div
            className={`absolute rounded-lg top-2 bottom-2 left-2 w-[calc(50%-0.5rem)]  bg-white transition-transform duration-500 ease-in-out ${
              mode === modes.signUp ? "translate-x-full" : "translate-x-0"
            }`}
          ></div>{" "}
        </div>
        {/* Forms */}
        <div className="w-full h-full overflow-x-hidden relative">
          <div
            className={`grid grid-cols-2 w-[200%] h-full transition-transform duration-500 ease-in-out ${
              mode === modes.signUp ? "transform -translate-x-1/2" : ""
            }`}
          >
            <LoginForm toggleMode={toggleMode} />
            <SignUpForm toggleMode={toggleMode} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Auth;
