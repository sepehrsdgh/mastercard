import React from 'react'

function SignUpForm() {
  return (
    <div>SignUpForm</div>
  )
}

export default SignUpForm